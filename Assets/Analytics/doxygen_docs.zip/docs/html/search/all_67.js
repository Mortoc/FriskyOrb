var searchData=
[
  ['googleuniversalanalytics',['GoogleUniversalAnalytics',['../class_google_universal_analytics.html',1,'GoogleUniversalAnalytics'],['../class_google_universal_analytics.html#a7345a1e95781ab6c967c6d61f98980e4',1,'GoogleUniversalAnalytics.GoogleUniversalAnalytics()']]]
];
